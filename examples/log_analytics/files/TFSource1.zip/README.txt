Content
Sources: [TFSource1]
Parsers: [TFParser1]
Fields: [TFField1, TFField2]

Reference
Fields: [mbody]
