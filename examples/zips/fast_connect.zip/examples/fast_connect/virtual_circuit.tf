// Copyright (c) 2017, 2024, Oracle and/or its affiliates. All rights reserved.
// Licensed under the Mozilla Public License v2.0

resource "oci_core_drg" "drg_private" {
  #Required
  compartment_id = var.compartment_ocid
}

resource "oci_core_virtual_circuit" "virtual_circuit_private" {
  #Required
  compartment_id = var.compartment_ocid
  type           = var.virtual_circuit_type_private

  #Required for PRIVATE VirtualCircuit
  bandwidth_shape_name = var.virtual_circuit_bandwidth_shape_name

  cross_connect_mappings {
    cross_connect_or_cross_connect_group_id = oci_core_cross_connect.cross_connect.cross_connect_group_id
    customer_bgp_peering_ip                 = var.virtual_circuit_cross_connect_mappings_customer_bgp_peering_ip
    oracle_bgp_peering_ip                   = var.virtual_circuit_cross_connect_mappings_oracle_bgp_peering_ip
    vlan                                    = var.virtual_circuit_cross_connect_mappings_vlan
  }

  customer_asn = var.virtual_circuit_customer_asn
  display_name = var.virtual_circuit_display_name
  gateway_id   = oci_core_drg.drg_private.id

  # Required when creating provider VC
  # provider_service_id       = oci_core_provider_service.provider_service.id
  # provider_service_key_name = var.virtual_circuit_provider_service_key_name

  # Required when creating OCI First MultiCloud VC
  # provider_remote_region = var.virtual_circuit_provider_remote_region
  # remote_account_id      = var.virtual_circuit_remote_account_id
  # Replace remote_account_id with provider_service_key_name when creating provider first MultiCloud VC

  region = var.virtual_circuit_region
}

resource "oci_core_virtual_circuit" "virtual_circuit_public" {
  #Required
  compartment_id = var.compartment_ocid
  type           = var.virtual_circuit_type_public

  #Required for PUBLIC Virtual Circuit
  bandwidth_shape_name = var.virtual_circuit_bandwidth_shape_name

  cross_connect_mappings {
    cross_connect_or_cross_connect_group_id = oci_core_cross_connect.cross_connect.cross_connect_group_id
    vlan                                    = var.virtual_circuit_cross_connect_mappings_vlan_public
  }

  customer_asn = var.virtual_circuit_customer_asn
  display_name = var.virtual_circuit_display_name

  #provider_service_id = oci_core_provider_service.provider_service.id

  public_prefixes {
    #Required
    cidr_block = var.virtual_circuit_public_prefixes_cidr_block
  }
  public_prefixes {
    cidr_block = var.virtual_circuit_public_prefixes_cidr_block2
  }
  public_prefixes {
    cidr_block = var.virtual_circuit_public_prefixes_cidr_block3
  }
  region = var.virtual_circuit_region
}

resource "oci_core_drg" "drg_provider_layer2" {
  #Required
  compartment_id = var.compartment_ocid
}

resource "oci_core_virtual_circuit" "virtual_circuit_provider_private_layer2" {
  // Create this resource only if there is a provider available that offers layer 2 private peering
  count = length(
    data.oci_core_fast_connect_provider_services.fast_connect_provider_services_private_layer2.fast_connect_provider_services,
  ) > 0 ? 1 : 0

  #Required
  compartment_id = var.compartment_ocid
  type           = var.virtual_circuit_type_private

  #Required for PRIVATE VirtualCircuit with Provider
  bandwidth_shape_name = var.virtual_circuit_bandwidth_shape_name

  cross_connect_mappings {
    customer_bgp_peering_ip = var.virtual_circuit_cross_connect_mappings_customer_bgp_peering_ip
    oracle_bgp_peering_ip   = var.virtual_circuit_cross_connect_mappings_oracle_bgp_peering_ip
  }

  customer_asn        = var.virtual_circuit_customer_asn
  display_name        = var.virtual_circuit_display_name
  gateway_id          = oci_core_drg.drg_provider_layer2.id
  provider_service_id = data.oci_core_fast_connect_provider_services.fast_connect_provider_services_private_layer2.fast_connect_provider_services[0].id
  region              = var.virtual_circuit_region
}

resource "oci_core_virtual_circuit" "virtual_circuit_provider_public_layer3" {
  // Create this resource only if there is a provider available that offers layer 3 public peering
  count = length(
    data.oci_core_fast_connect_provider_services.fast_connect_provider_services_public_layer3.fast_connect_provider_services,
  ) > 0 ? 1 : 0

  #Required
  compartment_id = var.compartment_ocid
  type           = var.virtual_circuit_type_public

  #Required for PRIVATE VirtualCircuit with Provider
  bandwidth_shape_name = var.virtual_circuit_bandwidth_shape_name
  display_name         = var.virtual_circuit_display_name
  provider_service_id  = data.oci_core_fast_connect_provider_services.fast_connect_provider_services_public_layer3.fast_connect_provider_services[0].id
  region               = var.virtual_circuit_region
}

data "oci_core_virtual_circuits" "virtual_circuits" {
  #Required
  compartment_id = var.compartment_ocid

  #Optional
  display_name = var.virtual_circuit_display_name
  state        = var.virtual_circuit_state

  depends_on = [
    oci_core_virtual_circuit.virtual_circuit_private,
    oci_core_virtual_circuit.virtual_circuit_public,
    oci_core_virtual_circuit.virtual_circuit_provider_private_layer2,
    oci_core_virtual_circuit.virtual_circuit_provider_public_layer3,
  ]
}

output "virtual_circuits" {
  value = [
    for virtual_circuit in data.oci_core_virtual_circuits.virtual_circuits.virtual_circuits : {
      id           = virtual_circuit.id
      display_name = virtual_circuit.display_name
      state        = virtual_circuit.state
      type         = virtual_circuit.type
    }
  ]
}

data "oci_core_virtual_circuit" "virtual_circuit" {
  virtual_circuit_id = oci_core_virtual_circuit.virtual_circuit_public.id
}

output "virtual_circuit" {
  value = {
    id    = data.oci_core_virtual_circuit.virtual_circuit.id
    state = data.oci_core_virtual_circuit.virtual_circuit.state
    type  = data.oci_core_virtual_circuit.virtual_circuit.type
  }
}
