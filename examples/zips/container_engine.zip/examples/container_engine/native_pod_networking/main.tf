// Copyright (c) 2017, 2024, Oracle and/or its affiliates. All rights reserved.
// Licensed under the Mozilla Public License v2.0

variable "tenancy_ocid" {
}

variable "user_ocid" {
}

variable "fingerprint" {
}

variable "private_key_path" {
}

variable "compartment_ocid" {
}

variable "region" {
  default = "us-ashburn-1"
}

variable "cluster_cluster_pod_network_options_cni_type" {
  default = "OCI_VCN_IP_NATIVE"
}

variable "node_pool_node_config_details_node_pool_pod_network_option_details_cni_type" {
  default = "OCI_VCN_IP_NATIVE"
}

variable "node_pool_node_config_details_node_pool_pod_network_option_details_max_pods_per_node" {
  default = 10
}

variable "node_pool_node_config_details_node_pool_pod_network_option_details_pod_nsg_ids" {
  default = []
}

variable "node_pool_node_config_details_node_pool_pod_network_option_details_pod_subnet_ids" {
  default = []
}

# Provide the SSH public key to be set on each node in the node pool on launch.
variable "node_pool_ssh_public_key" {
  default = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDOuBJgh6lTmQvQJ4BA3RCJdSmxRtmiXAQEEIP68/G4gF3XuZdKEYTFeputacmRq9yO5ZnNXgO9akdUgePpf8+CfFtveQxmN5xo3HVCDKxu/70lbMgeu7+wJzrMOlzj+a4zNq2j0Ww2VWMsisJ6eV3bJTnO/9VLGCOC8M9noaOlcKcLgIYy4aDM724MxFX2lgn7o6rVADHRxkvLEXPVqYT4syvYw+8OVSnNgE4MJLxaw8/2K0qp19YlQyiriIXfQpci3ThxwLjymYRPj+kjU1xIxv6qbFQzHR7ds0pSWp1U06cIoKPfCazU9hGWW8yIe/vzfTbWrt2DK6pLwBn/G0x3 sample"
}

variable "node_pool_node_config_details_size" {
  default = 1
}

provider "oci" {
  region              = var.region
  auth                = "SecurityToken"
  config_file_profile = "terraform-federation-test"
}

data "oci_identity_availability_domain" "ad1" {
  compartment_id = var.tenancy_ocid
  ad_number      = 1
}

data "oci_identity_availability_domain" "ad2" {
  compartment_id = var.tenancy_ocid
  ad_number      = 2
}

data "oci_containerengine_cluster_option" "test_cluster_option" {
  cluster_option_id = "all"
}

resource "oci_core_vcn" "test_vcn" {
  cidr_block     = "10.0.0.0/16"
  compartment_id = var.compartment_ocid
  display_name   = "tfVcnForClusters"
}

resource "oci_core_internet_gateway" "test_ig" {
  compartment_id = var.compartment_ocid
  display_name   = "tfClusterInternetGateway"
  vcn_id         = oci_core_vcn.test_vcn.id
}

resource "oci_core_route_table" "test_route_table" {
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.test_vcn.id
  display_name   = "tfClustersRouteTable"

  route_rules {
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
    network_entity_id = oci_core_internet_gateway.test_ig.id
  }
}

resource "oci_core_subnet" "nodePool_Subnet_1" {
  #Required
  cidr_block     = "10.0.22.0/24"
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.test_vcn.id

  # Provider code tries to maintain compatibility with old versions.
  security_list_ids = [oci_core_vcn.test_vcn.default_security_list_id]
  display_name      = "tfSubNet1ForNodePool"
  route_table_id    = oci_core_route_table.test_route_table.id
}

resource "oci_core_subnet" "clusterSubnet_1" {
  #Required
  cidr_block     = "10.0.21.0/24"
  compartment_id = var.compartment_ocid
  vcn_id         = oci_core_vcn.test_vcn.id
  display_name   = "tfSubNet1ForClusters"

  # Provider code tries to maintain compatibility with old versions.
  security_list_ids = [oci_core_vcn.test_vcn.default_security_list_id]
  route_table_id    = oci_core_route_table.test_route_table.id
}

resource "oci_core_compute_cluster" "test_compute_cluster" {
  availability_domain = data.oci_identity_availability_domain.ad1.name
  compartment_id      = var.compartment_ocid
  display_name        = "TestComputeCluster"
}

resource "oci_core_compute_host_group" "test_host_group" {
  availability_domain            = data.oci_identity_availability_domain.ad1.name
  compartment_id                 = var.compartment_ocid
  display_name                   = "testHostGroup"
  is_targeted_placement_required = true

  configurations {
    target        = "BM.GPU4.8"
    recycle_level = "SKIP_RECYCLE"
  }
}

resource "oci_containerengine_cluster" "test_npn_cluster" {
  #Required
  compartment_id     = var.compartment_ocid
  kubernetes_version = local.compute_cluster_node_pool_kubernetes_version
  name               = "tfTestCluster"
  type               = "ENHANCED_CLUSTER"
  vcn_id             = oci_core_vcn.test_vcn.id

  cluster_pod_network_options {
    #Required
    cni_type = var.cluster_cluster_pod_network_options_cni_type
  }

  #Optional
  options {
    service_lb_subnet_ids = [oci_core_subnet.clusterSubnet_1.id]
  }

  # required regional subnet for Native Pod Networking
  endpoint_config {
    subnet_id = oci_core_subnet.clusterSubnet_1.id
  }
}

resource "oci_containerengine_cluster" "test_zpr_cluster" {
  #Required
  compartment_id     = var.compartment_ocid
  kubernetes_version = reverse(data.oci_containerengine_cluster_option.test_cluster_option.kubernetes_versions)[0]
  name               = "tfTestCluster"
  vcn_id             = oci_core_vcn.test_vcn.id

  cluster_pod_network_options {
    #Required
    cni_type = var.cluster_cluster_pod_network_options_cni_type
  }

  #Optional
  options {
    service_lb_subnet_ids = [oci_core_subnet.clusterSubnet_1.id]
  }

  # required regional subnet for Native Pod Networking
  endpoint_config {
    subnet_id = oci_core_subnet.clusterSubnet_1.id
    security_attributes = {
      "oracle-zpr.sensitivity.value": "false",
      "oracle-zpr.sensitivity.mode":  "enforce",
    }
  }
}

resource "oci_containerengine_node_pool" "test_node_pool" {
  #Required
  cluster_id         = oci_containerengine_cluster.test_npn_cluster.id
  compartment_id     = var.compartment_ocid
  kubernetes_version = reverse(data.oci_containerengine_cluster_option.test_cluster_option.kubernetes_versions)[0]
  name               = "tfPool"
  node_shape         = "VM.Standard2.1"

  #Optional
  initial_node_labels {
    #Optional
    key   = "key"
    value = "value"
  }

  node_source_details {
    #Required
    image_id    = local.image_id
    source_type = "IMAGE"
  }

  node_config_details {
    #Required
    placement_configs {
      #Required
      availability_domain = data.oci_identity_availability_domain.ad1.name
      subnet_id           = oci_core_subnet.nodePool_Subnet_1.id
    }
    size = var.node_pool_node_config_details_size

    node_pool_pod_network_option_details {
        #Required
        cni_type = var.node_pool_node_config_details_node_pool_pod_network_option_details_cni_type

        #Optional
        max_pods_per_node = var.node_pool_node_config_details_node_pool_pod_network_option_details_max_pods_per_node
        pod_nsg_ids       = var.node_pool_node_config_details_node_pool_pod_network_option_details_pod_nsg_ids
        pod_subnet_ids    = [oci_core_subnet.nodePool_Subnet_1.id]
    }
  }

  node_metadata = {
    "areLegacyImdsEndpointsDisabled" = "true"
  }

  ssh_public_key      = var.node_pool_ssh_public_key

  node_pool_cycling_details {
    is_node_cycling_enabled = "true"
    cycle_modes = ["INSTANCE_REPLACE"]
  }
}

resource "oci_containerengine_node_pool" "test_node_pool_secondary_vnics" {
  #Required
  cluster_id         = oci_containerengine_cluster.test_npn_cluster.id
  compartment_id     = var.compartment_ocid
  kubernetes_version = reverse(data.oci_containerengine_cluster_option.test_cluster_option.kubernetes_versions)[0]
  name               = "tfPool"
  node_shape         = "VM.Standard.E3.flex"

  node_source_details {
    #Required
    image_id    = local.image_id
    source_type = "IMAGE"
  }

  node_config_details {
    #Required
    placement_configs {
      #Required
      availability_domain = data.oci_identity_availability_domain.ad1.name
      subnet_id           = oci_core_subnet.nodePool_Subnet_1.id
    }
    size = var.node_pool_node_config_details_size

    node_pool_pod_network_option_details {
      #Required
      cni_type = var.node_pool_node_config_details_node_pool_pod_network_option_details_cni_type
    }
  }

  network_launch_type = "VFIO"

  secondary_vnics {
    create_vnic_details {
      subnet_id = oci_core_subnet.nodePool_Subnet_1.id
      ip_count  = 8
      application_resources = ["blue"]
      display_name = "vnic1"
      security_attributes = {
        "oracle-zpr.sensitivity.value": "false",
        "oracle-zpr.sensitivity.mode":  "enforce",
      }
    }
    display_name = "vnic-attachment-1"
    nic_index = 1
  }

  secondary_vnics {
    create_vnic_details {
      subnet_id = oci_core_subnet.nodePool_Subnet_1.id
      ip_count  = 8
      application_resources = ["blue"]
      display_name = "vnic2"
      security_attributes = {
        "oracle-zpr.sensitivity.value": "false",
        "oracle-zpr.sensitivity.mode":  "enforce",
      }
    }
    display_name = "vnic-attachment2"
    nic_index = 0
  }

  primary_vnic {
    security_attributes = {
      "oracle-zpr.sensitivity.value": "false",
      "oracle-zpr.sensitivity.mode":  "enforce",
    }
  }

  node_metadata = {
    "areLegacyImdsEndpointsDisabled" = "true"
  }

  node_shape_config {
    ocpus = 3.0
  }

  ssh_public_key      = var.node_pool_ssh_public_key
}


data "oci_containerengine_cluster_kube_config" "test_cluster_kube_config" {
    #Required
    cluster_id = oci_containerengine_cluster.test_npn_cluster.id
}

output "node_pool" {
  value = {
    id                 = oci_containerengine_node_pool.test_node_pool.id
    kubernetes_version = oci_containerengine_node_pool.test_node_pool.kubernetes_version
    name               = oci_containerengine_node_pool.test_node_pool.name
    subnet_ids         = oci_containerengine_node_pool.test_node_pool.subnet_ids
  }
}

output "cluster" {
    value = {
        kubeconfig = data.oci_containerengine_cluster_kube_config.test_cluster_kube_config.content
    }
}

output "secondary_vnics_node_pool" {
  value = {
    id                 = oci_containerengine_node_pool.test_node_pool_secondary_vnics.id
    kubernetes_version = oci_containerengine_node_pool.test_node_pool_secondary_vnics.kubernetes_version
    name               = oci_containerengine_node_pool.test_node_pool_secondary_vnics.name
  }
}


resource "oci_containerengine_node_pool" "compute_cluster_nodePool" {
  compartment_id     = var.compartment_ocid
  cluster_id         = oci_containerengine_cluster.test_npn_cluster.id
  kubernetes_version = local.compute_cluster_node_pool_kubernetes_version
  name               = "compute_cluster_nodePool"
  node_shape         = "BM.GPU4.8"

  node_config_details {
    size               = 0
    compute_cluster_id = oci_core_compute_cluster.test_compute_cluster.id

    placement_configs {
      availability_domain = data.oci_identity_availability_domain.ad1.name
      subnet_id           = oci_core_subnet.nodePool_Subnet_1.id
      host_group_id       = oci_core_compute_host_group.test_host_group.id
    }

    node_pool_pod_network_option_details {
      #Required
      cni_type       = var.node_pool_node_config_details_node_pool_pod_network_option_details_cni_type
      pod_subnet_ids = [oci_core_subnet.nodePool_Subnet_1.id]
    }
  }

  node_metadata = { "areLegacyImdsEndpointsDisabled" : "true" }
  node_source_details {
    #Required
    image_id    = local.gpu_image_id
    source_type = "IMAGE"
  }
}


data "oci_containerengine_node_pool_option" "test_node_pool_option" {
  node_pool_option_id = "all"
  compartment_id      = var.compartment_ocid
}

data "oci_core_images" "shape_specific_images" {
  #Required
  compartment_id = var.tenancy_ocid
  shape          = "VM.Standard2.1"
}


locals {
  compute_cluster_node_pool_kubernetes_version = "v1.35.2"
  compute_cluster_node_pool_oke_image_version  = replace(local.compute_cluster_node_pool_kubernetes_version, "v", "")

  all_images  = data.oci_core_images.shape_specific_images.images
  all_sources = data.oci_containerengine_node_pool_option.test_node_pool_option.sources

  compartment_images = [for image in local.all_images : image.id if length(regexall("Oracle-Linux-[0-9]*.[0-9]*-20[0-9]*", image.display_name)) > 0]

  oracle_linux_images = [for source in local.all_sources : source.image_id if length(regexall("Oracle-Linux-[0-9]*.[0-9]*-20[0-9]*", source.source_name)) > 0]

  image_id = tolist(setintersection(toset(local.compartment_images), toset(local.oracle_linux_images)))[0]

  gpu_compartment_images = [
    for image in local.all_images : image.id
    if length(regexall("Oracle-Linux-[0-9]+[.][0-9]+.*GPU.*20[0-9]+", image.display_name)) > 0
  ]

  gpu_oracle_linux_images = [
    for source in local.all_sources : source.image_id
    if length(regexall("Oracle-Linux-[0-9]+[.][0-9]+.*GPU.*20[0-9]+", source.source_name)) > 0 &&
    length(regexall("OKE-${local.compute_cluster_node_pool_oke_image_version}-", source.source_name)) > 0
  ]

  gpu_image_id = local.gpu_oracle_linux_images[0]
}
