# Overview
This is a Terraform configuration that creates the Globally Distributed Database service on Oracle Cloud Infrastructure.
## Magic Button 
[![Deploy to Oracle Cloud](https://oci-resourcemanager-plugin.plugins.oci.oraclecloud.com/latest/deploy-to-oracle-cloud.svg)](https://cloud.oracle.com/resourcemanager/stacks/create?zipUrl=https://github.com/oracle/terraform-provider-oci/raw/master/examples/zips/globally_distributed_database.zip)