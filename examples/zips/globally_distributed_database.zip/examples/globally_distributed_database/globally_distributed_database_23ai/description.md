# Overview
This is a Terraform configuration that creates the Globally Distributed Database 23ai service on Oracle Cloud Infrastructure.