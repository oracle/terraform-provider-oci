# Overview
This is a Terraform configuration that creates the Globally Distributed Database service on Oracle Cloud Infrastructure.