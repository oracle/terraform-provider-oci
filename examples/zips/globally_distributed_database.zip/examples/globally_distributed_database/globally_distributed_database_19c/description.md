# Overview
This is a Terraform configuration that creates the Globally Distributed Database 19c service on Oracle Cloud Infrastructure.