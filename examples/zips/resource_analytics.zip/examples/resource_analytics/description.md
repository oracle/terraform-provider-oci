# Overview
This is a Terraform configuration that creates a Resource Analytics Instance on Oracle Cloud Infrastructure.

The Terraform code is used to create a Resource Analytics Instance, add a Tenancy Attachment, add Monitored Regions, and Enable OAC. Some steps are optional and can be removed.