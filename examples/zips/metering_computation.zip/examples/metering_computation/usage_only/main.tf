// Copyright (c) 2017, 2024, Oracle and/or its affiliates. All rights reserved.

// These variables would commonly be defined as environment variables or sourced in a .env file

variable "tenancy_ocid" {
}

variable "region" {
}

provider "oci" {
  auth                = "SecurityToken"
  config_file_profile = "terraform-federation-test"
}

variable "time_usage_ended" {
  default = "2020-01-02T00:00:00.000Z"
}

variable "time_usage_started" {
  default = "2020-01-01T00:00:00.000Z"
}

variable "dimensions_value" {
  default = "dimensions_value"
}

resource "oci_metering_computation_usage" "test_usage" {
  #Required
  granularity        = "DAILY"
  tenant_id          = var.tenancy_ocid
  time_usage_ended   = var.time_usage_ended
  time_usage_started = var.time_usage_started

  #Optional
  compartment_depth = 1

  filter = <<EOF
{
        "operator": "AND",
        "dimensions": [],
        "tags": [],
        "filters": [
            {
				"operator": "OR",
                "dimensions": [
				    {
                        "key": "compartmentName",
                        "value": "${var.dimensions_value}"
					}
                ],
                "filters": [],
                "tags": []
		    }
        ]
}
EOF

  group_by   = ["service"]
  query_type = "USAGE_ONLY"
}

data "oci_metering_computation_configuration" "test_configuration" {
  tenant_id = var.tenancy_ocid
}
