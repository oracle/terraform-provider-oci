// Copyright (c) 2017, 2024, Oracle and/or its affiliates. All rights reserved.
// Licensed under the Mozilla Public License v2.0

variable "tenancy_ocid" {}
variable "user_ocid" {}
variable "fingerprint" {}
variable "private_key_path" {}
variable "region" {}
variable "apm_domain_id" {}

variable "trace_trace_key" {
  default = "traceKey"
}

variable "trace_time_trace_started_greater_than_or_equal_to" {
  default = "YYYY-MM-DDTHH:MM:SS.SSSZ"
}

variable "trace_time_trace_started_less_than" {
  default = "YYYY-MM-DDTHH:MM:SS.SSSZ"
}

variable "trace_trace_namespace" {
  default = "TRACES"
}

provider "oci" {
  tenancy_ocid     = var.tenancy_ocid
  user_ocid        = var.user_ocid
  fingerprint      = var.fingerprint
  private_key_path = var.private_key_path
  region           = var.region
}

data "oci_apm_traces_trace" "test_trace" {
  #Required
  apm_domain_id = var.apm_domain_id
  trace_key     = var.trace_trace_key

  #Optional
  trace_namespace = var.trace_trace_namespace
  time_trace_started_greater_than_or_equal_to = var.trace_time_trace_started_greater_than_or_equal_to
  time_trace_started_less_than = var.trace_time_trace_started_less_than

}

