# Overview
This is a Terraform configuration that creates the Oracle Content Experience service on Oracle Cloud Infrastructure.

The Terraform code is used to create a Resource Manager stack, that creates the required resources and configures the application on the created resources.